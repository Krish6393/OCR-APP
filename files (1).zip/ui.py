"""
ui.py
Tkinter desktop UI for the Daikin OCR Tool.
Industrial dark theme — built for service-center use.
"""

import os
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageTk
import pandas as pd

from ocr_engine import ocr_with_fallback, detect_label_region, highlight_detections, preprocess
from extractor import extract, ExtractionResult

BG_DARK  = "#0f1117"
BG_PANEL = "#1a1d27"
BG_CARD  = "#22263a"
ACCENT   = "#00c8ff"
ACCENT2  = "#0077b6"
SUCCESS  = "#00e676"
WARNING  = "#ffab40"
ERROR_CLR= "#ff5252"
TEXT_PRI = "#e8eaf6"
TEXT_SEC = "#8892b0"
TEXT_MONO= "#64ffda"
BORDER   = "#2e3250"

FONT_TITLE = ("Consolas", 13, "bold")
FONT_LABEL = ("Consolas", 10)
FONT_VALUE = ("Consolas", 14, "bold")
FONT_SMALL = ("Consolas", 9)
FONT_BTN   = ("Consolas", 10, "bold")
FONT_STATUS= ("Consolas", 9)

PREVIEW_W, PREVIEW_H = 520, 300


class DaikinOCRApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Daikin AC Label OCR  v1.0")
        self.configure(bg=BG_DARK)
        self.resizable(True, True)
        self.minsize(900, 680)
        self._image_paths = []
        self._current_idx = 0
        self._results = []
        self._cv_original = None
        self._photo_ref = None
        self._last_ocr_data = None
        self._build_ui()
        self._bind_shortcuts()

    def _build_ui(self):
        self.columnconfigure(0, weight=0)
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)
        self._build_sidebar()
        self._build_main()
        self._build_statusbar()

    def _build_sidebar(self):
        sidebar = tk.Frame(self, bg=BG_PANEL, width=210)
        sidebar.grid(row=0, column=0, sticky="nsew")
        sidebar.grid_propagate(False)
        sidebar.columnconfigure(0, weight=1)
        logo_frame = tk.Frame(sidebar, bg=BG_PANEL, pady=18)
        logo_frame.grid(row=0, column=0, sticky="ew")
        tk.Label(logo_frame, text="◈ DAIKIN", font=("Consolas", 16, "bold"),
                 bg=BG_PANEL, fg=ACCENT).pack()
        tk.Label(logo_frame, text="LABEL  OCR", font=("Consolas", 9),
                 bg=BG_PANEL, fg=TEXT_SEC).pack()
        tk.Frame(sidebar, bg=BORDER, height=1).grid(row=1, column=0, sticky="ew", padx=10)
        btn_frame = tk.Frame(sidebar, bg=BG_PANEL, pady=14)
        btn_frame.grid(row=2, column=0, sticky="ew")
        btn_frame.columnconfigure(0, weight=1)
        self._btn_upload = self._sidebar_btn(btn_frame, "▲  Upload Image", self._upload_single, ACCENT, 0)
        self._btn_batch  = self._sidebar_btn(btn_frame, "⊞  Batch Images", self._upload_batch, ACCENT2, 1)
        self._btn_run    = self._sidebar_btn(btn_frame, "▶  Run OCR", self._run_ocr, SUCCESS, 2, state="disabled")
        self._btn_export = self._sidebar_btn(btn_frame, "↓  Export Excel", self._export_excel, WARNING, 3, state="disabled")
        tk.Frame(sidebar, bg=BORDER, height=1).grid(row=3, column=0, sticky="ew", padx=10)
        tk.Label(sidebar, text="QUEUED FILES", font=FONT_SMALL, bg=BG_PANEL, fg=TEXT_SEC, pady=8).grid(row=4, column=0)
        list_frame = tk.Frame(sidebar, bg=BG_PANEL)
        list_frame.grid(row=5, column=0, sticky="nsew", padx=8, pady=(0, 8))
        list_frame.columnconfigure(0, weight=1)
        list_frame.rowconfigure(0, weight=1)
        sidebar.rowconfigure(5, weight=1)
        scrollbar = tk.Scrollbar(list_frame, bg=BORDER, troughcolor=BG_DARK, activebackground=ACCENT, width=6)
        self._file_listbox = tk.Listbox(list_frame, bg=BG_DARK, fg=TEXT_SEC,
            selectbackground=ACCENT2, selectforeground=TEXT_PRI, font=FONT_SMALL,
            borderwidth=0, highlightthickness=0, yscrollcommand=scrollbar.set, activestyle="none")
        scrollbar.config(command=self._file_listbox.yview)
        self._file_listbox.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
        self._file_listbox.bind("<<ListboxSelect>>", self._on_list_select)

    def _sidebar_btn(self, parent, text, cmd, color, row, state="normal"):
        btn = tk.Button(parent, text=text, command=cmd, font=FONT_BTN,
            bg=BG_CARD, fg=color, activebackground=BG_DARK, activeforeground=color,
            borderwidth=1, relief="flat", highlightbackground=BORDER, highlightthickness=1,
            pady=9, cursor="hand2", state=state)
        btn.grid(row=row, column=0, sticky="ew", padx=10, pady=4)
        btn.bind("<Enter>", lambda e, b=btn: b.config(bg=BG_DARK))
        btn.bind("<Leave>", lambda e, b=btn: b.config(bg=BG_CARD))
        return btn

    def _build_main(self):
        main = tk.Frame(self, bg=BG_DARK)
        main.grid(row=0, column=1, sticky="nsew", padx=12, pady=12)
        main.columnconfigure(0, weight=1)
        main.rowconfigure(1, weight=1)
        header = tk.Frame(main, bg=BG_DARK)
        header.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        tk.Label(header, text="AC UNIT LABEL SCANNER", font=("Consolas", 11, "bold"),
                 bg=BG_DARK, fg=ACCENT).pack(side="left")
        tk.Label(header, text="  ·  Model & Serial Extractor", font=FONT_SMALL,
                 bg=BG_DARK, fg=TEXT_SEC).pack(side="left")
        content = tk.Frame(main, bg=BG_DARK)
        content.grid(row=1, column=0, sticky="nsew")
        content.columnconfigure(0, weight=3)
        content.columnconfigure(1, weight=2)
        content.rowconfigure(0, weight=1)
        self._build_preview_panel(content)
        self._build_result_panel(content)

    def _build_preview_panel(self, parent):
        frame = tk.LabelFrame(parent, text=" IMAGE PREVIEW ", font=FONT_SMALL,
            bg=BG_PANEL, fg=TEXT_SEC, borderwidth=1, relief="flat",
            highlightbackground=BORDER, highlightthickness=1)
        frame.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)
        self._preview_canvas = tk.Canvas(frame, bg=BG_DARK, bd=0, highlightthickness=0,
                                         width=PREVIEW_W, height=PREVIEW_H)
        self._preview_canvas.grid(row=0, column=0, sticky="nsew", padx=8, pady=8)
        self._preview_canvas.bind("<Configure>", self._on_canvas_resize)
        self._draw_placeholder()
        toggle_frame = tk.Frame(frame, bg=BG_PANEL)
        toggle_frame.grid(row=1, column=0, pady=(0, 8))
        self._show_processed = tk.BooleanVar(value=False)
        tk.Checkbutton(toggle_frame, text="Show preprocessed", variable=self._show_processed,
            command=self._refresh_preview, font=FONT_SMALL, bg=BG_PANEL, fg=TEXT_SEC,
            selectcolor=BG_DARK, activebackground=BG_PANEL, activeforeground=ACCENT).pack(side="left", padx=6)
        self._highlight_var = tk.BooleanVar(value=True)
        tk.Checkbutton(toggle_frame, text="Highlight detections", variable=self._highlight_var,
            command=self._refresh_preview, font=FONT_SMALL, bg=BG_PANEL, fg=TEXT_SEC,
            selectcolor=BG_DARK, activebackground=BG_PANEL, activeforeground=ACCENT).pack(side="left", padx=6)

    def _build_result_panel(self, parent):
        frame = tk.LabelFrame(parent, text=" EXTRACTION RESULTS ", font=FONT_SMALL,
            bg=BG_PANEL, fg=TEXT_SEC, borderwidth=1, relief="flat",
            highlightbackground=BORDER, highlightthickness=1)
        frame.grid(row=0, column=1, sticky="nsew")
        frame.columnconfigure(0, weight=1)
        self._model_label  = self._result_card(frame, "MODEL NUMBER", row=0, accent=ACCENT)
        self._serial_label = self._result_card(frame, "SERIAL NUMBER", row=1, accent=SUCCESS)
        conf_frame = tk.Frame(frame, bg=BG_PANEL)
        conf_frame.grid(row=2, column=0, sticky="ew", padx=12, pady=6)
        conf_frame.columnconfigure(1, weight=1)
        tk.Label(conf_frame, text="OCR Confidence", font=FONT_SMALL,
                 bg=BG_PANEL, fg=TEXT_SEC).grid(row=0, column=0, sticky="w")
        self._conf_bar = ttk.Progressbar(conf_frame, length=140, maximum=100, mode="determinate")
        self._conf_bar.grid(row=0, column=1, padx=8)
        self._conf_lbl = tk.Label(conf_frame, text="—", font=FONT_SMALL,
                                  bg=BG_PANEL, fg=TEXT_MONO, width=6)
        self._conf_lbl.grid(row=0, column=2)
        tk.Label(conf_frame, text="Elapsed", font=FONT_SMALL,
                 bg=BG_PANEL, fg=TEXT_SEC).grid(row=1, column=0, sticky="w", pady=(4, 0))
        self._elapsed_lbl = tk.Label(conf_frame, text="—", font=FONT_SMALL, bg=BG_PANEL, fg=TEXT_MONO)
        self._elapsed_lbl.grid(row=1, column=1, columnspan=2, sticky="w", padx=8)
        copy_frame = tk.Frame(frame, bg=BG_PANEL)
        copy_frame.grid(row=3, column=0, sticky="ew", padx=12, pady=4)
        copy_frame.columnconfigure(0, weight=1)
        copy_frame.columnconfigure(1, weight=1)
        self._cp_model_btn  = self._mini_btn(copy_frame, "Copy Model",  self._copy_model,  0, 0)
        self._cp_serial_btn = self._mini_btn(copy_frame, "Copy Serial", self._copy_serial, 0, 1)
        warn_frame = tk.Frame(frame, bg=BG_PANEL)
        warn_frame.grid(row=4, column=0, sticky="ew", padx=12, pady=(0, 6))
        warn_frame.columnconfigure(0, weight=1)
        self._warn_lbl = tk.Label(warn_frame, text="", font=FONT_SMALL,
                                  bg=BG_PANEL, fg=WARNING, wraplength=220, justify="left")
        self._warn_lbl.grid(row=0, column=0, sticky="w")
        raw_frame = tk.LabelFrame(frame, text=" RAW OCR TEXT ", font=FONT_SMALL,
            bg=BG_PANEL, fg=TEXT_SEC, borderwidth=1, relief="flat",
            highlightbackground=BORDER, highlightthickness=1)
        raw_frame.grid(row=5, column=0, sticky="nsew", padx=12, pady=(0, 12))
        raw_frame.columnconfigure(0, weight=1)
        raw_frame.rowconfigure(0, weight=1)
        frame.rowconfigure(5, weight=1)
        self._raw_text = tk.Text(raw_frame, bg=BG_DARK, fg=TEXT_SEC, font=FONT_SMALL,
            borderwidth=0, highlightthickness=0, wrap="word", state="disabled", height=8)
        raw_scroll = tk.Scrollbar(raw_frame, command=self._raw_text.yview,
                                  bg=BORDER, troughcolor=BG_DARK, width=6)
        self._raw_text.config(yscrollcommand=raw_scroll.set)
        self._raw_text.grid(row=0, column=0, sticky="nsew", padx=4, pady=4)
        raw_scroll.grid(row=0, column=1, sticky="ns")

    def _result_card(self, parent, title, row, accent):
        card = tk.Frame(parent, bg=BG_CARD, padx=12, pady=10)
        card.grid(row=row, column=0, sticky="ew", padx=12, pady=(10 if row == 0 else 4, 0))
        card.columnconfigure(1, weight=1)
        tk.Label(card, text=title, font=FONT_SMALL, bg=BG_CARD, fg=TEXT_SEC).grid(
            row=0, column=0, columnspan=2, sticky="w")
        indicator = tk.Label(card, text="●", font=("Consolas", 12), bg=BG_CARD, fg=BORDER)
        indicator.grid(row=1, column=0, sticky="w", padx=(0, 8))
        value_lbl = tk.Label(card, text="—", font=FONT_VALUE, bg=BG_CARD, fg=accent)
        value_lbl.grid(row=1, column=1, sticky="w")
        value_lbl._indicator = indicator
        value_lbl._accent    = accent
        return value_lbl

    def _mini_btn(self, parent, text, cmd, row, col):
        btn = tk.Button(parent, text=text, command=cmd, font=FONT_SMALL,
            bg=BG_DARK, fg=TEXT_SEC, activebackground=BG_PANEL, activeforeground=ACCENT,
            borderwidth=1, relief="flat", highlightbackground=BORDER, highlightthickness=1,
            pady=4, cursor="hand2")
        btn.grid(row=row, column=col, sticky="ew", pady=2, padx=(0, 4 if col == 0 else 0))
        return btn

    def _build_statusbar(self):
        bar = tk.Frame(self, bg=BG_PANEL, height=26)
        bar.grid(row=1, column=0, columnspan=2, sticky="ew")
        bar.grid_propagate(False)
        bar.columnconfigure(1, weight=1)
        self._status_icon = tk.Label(bar, text="◉", font=FONT_SMALL, bg=BG_PANEL, fg=TEXT_SEC)
        self._status_icon.grid(row=0, column=0, padx=(10, 4))
        self._status_lbl = tk.Label(bar, text="Ready. Upload an image to begin.",
            font=FONT_STATUS, bg=BG_PANEL, fg=TEXT_SEC, anchor="w")
        self._status_lbl.grid(row=0, column=1, sticky="ew")
        self._batch_lbl = tk.Label(bar, text="", font=FONT_STATUS, bg=BG_PANEL, fg=TEXT_SEC)
        self._batch_lbl.grid(row=0, column=2, padx=10)

    def _bind_shortcuts(self):
        self.bind("<Control-o>", lambda e: self._upload_single())
        self.bind("<Return>",    lambda e: self._run_ocr())

    def _set_status(self, msg, color=TEXT_SEC, icon="◉"):
        self._status_icon.config(text=icon, fg=color)
        self._status_lbl.config(text=msg, fg=color)

    def _draw_placeholder(self):
        self._preview_canvas.delete("all")
        w = self._preview_canvas.winfo_width()  or PREVIEW_W
        h = self._preview_canvas.winfo_height() or PREVIEW_H
        self._preview_canvas.create_rectangle(0, 0, w, h, fill=BG_DARK, outline="")
        self._preview_canvas.create_text(w//2, h//2,
            text="[ No image loaded ]\n\nUpload a Daikin AC label image\nCtrl+O or use the sidebar button",
            fill=BORDER, font=FONT_SMALL, justify="center")

    def _on_canvas_resize(self, event):
        if self._cv_original is not None:
            self._refresh_preview()
        else:
            self._draw_placeholder()

    def _display_image(self, cv_img):
        cw = self._preview_canvas.winfo_width()  or PREVIEW_W
        ch = self._preview_canvas.winfo_height() or PREVIEW_H
        if len(cv_img.shape) == 3:
            rgb = cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB)
        else:
            rgb = cv2.cvtColor(cv_img, cv2.COLOR_GRAY2RGB)
        pil = Image.fromarray(rgb)
        pil.thumbnail((cw, ch), Image.LANCZOS)
        self._photo_ref = ImageTk.PhotoImage(pil)
        self._preview_canvas.delete("all")
        self._preview_canvas.create_image(cw//2, ch//2, anchor="center", image=self._photo_ref)

    def _refresh_preview(self):
        if self._cv_original is None:
            return
        if self._show_processed.get():
            img = preprocess(self._cv_original)
        else:
            img = self._cv_original.copy()
            if self._highlight_var.get() and self._last_ocr_data:
                img = highlight_detections(img, self._last_ocr_data,
                                           ["model", "ser", "serial", "s/no"])
        self._display_image(img)

    def _upload_single(self):
        path = filedialog.askopenfilename(title="Select Daikin AC Label Image",
            filetypes=[("Images", "*.jpg *.jpeg *.png *.bmp *.tiff"), ("All", "*.*")])
        if not path:
            return
        self._image_paths = [path]
        self._current_idx = 0
        self._load_image(path)
        self._update_file_list()

    def _upload_batch(self):
        paths = filedialog.askopenfilenames(title="Select Multiple Images",
            filetypes=[("Images", "*.jpg *.jpeg *.png *.bmp *.tiff"), ("All", "*.*")])
        if not paths:
            return
        self._image_paths = list(paths)
        self._current_idx = 0
        self._load_image(self._image_paths[0])
        self._update_file_list()

    def _load_image(self, path):
        img = cv2.imread(path)
        if img is None:
            messagebox.showerror("Error", f"Cannot read image:\n{path}")
            return
        self._cv_original   = img
        self._last_ocr_data = None
        self._display_image(img)
        self._btn_run.config(state="normal")
        self._set_status(f"Loaded: {Path(path).name}", ACCENT, "◈")
        self._batch_lbl.config(text=f"  {self._current_idx + 1} / {len(self._image_paths)}")

    def _update_file_list(self):
        self._file_listbox.delete(0, "end")
        for p in self._image_paths:
            self._file_listbox.insert("end", Path(p).name)
        if self._image_paths:
            self._file_listbox.selection_set(self._current_idx)

    def _on_list_select(self, event):
        sel = self._file_listbox.curselection()
        if sel:
            idx = sel[0]
            if idx != self._current_idx:
                self._current_idx = idx
                self._load_image(self._image_paths[idx])

    def _run_ocr(self):
        if not self._image_paths:
            return
        self._btn_run.config(state="disabled", text="▶  Processing…")
        self._set_status("Running OCR…", WARNING, "◌")
        threading.Thread(target=self._ocr_worker, daemon=True).start()

    def _ocr_worker(self):
        try:
            if len(self._image_paths) == 1:
                self._process_single(self._cv_original, self._image_paths[0])
            else:
                self._process_batch()
        except Exception as exc:
            self.after(0, self._set_status, f"Error: {exc}", ERROR_CLR, "✕")
        finally:
            self.after(0, self._btn_run.config, {"state": "normal", "text": "▶  Run OCR"})

    def _process_single(self, cv_img, path):
        ocr_result = ocr_with_fallback(cv_img)
        ext_result = extract(ocr_result["text"], ocr_result["confidence"])
        self.after(0, self._update_results, ocr_result, ext_result, path)

    def _process_batch(self):
        self._results = []
        for i, path in enumerate(self._image_paths):
            img = cv2.imread(path)
            if img is None:
                continue
            ocr_result = ocr_with_fallback(img)
            ext_result = extract(ocr_result["text"], ocr_result["confidence"])
            self._results.append({
                "File":          Path(path).name,
                "Model Number":  ext_result.model_number  or "NOT FOUND",
                "Serial Number": ext_result.serial_number or "NOT FOUND",
                "Confidence":    round(ocr_result["confidence"], 1),
                "Elapsed (s)":   round(ocr_result["elapsed"], 3),
            })
            if i == self._current_idx:
                self.after(0, self._update_results, ocr_result, ext_result, path)
            self.after(0, self._set_status, f"Batch: {i+1}/{len(self._image_paths)}…", WARNING, "◌")
        self.after(0, self._btn_export.config, {"state": "normal"})
        self.after(0, self._set_status,
                   f"Batch complete. {len(self._results)} images processed.", SUCCESS, "✓")

    def _update_results(self, ocr_result, ext_result, path):
        self._last_ocr_data = ocr_result["data"]
        model  = ext_result.model_number  or "—"
        serial = ext_result.serial_number or "—"
        self._model_label.config(text=model)
        self._model_label._indicator.config(fg=SUCCESS if ext_result.model_number else ERROR_CLR)
        self._serial_label.config(text=serial)
        self._serial_label._indicator.config(fg=SUCCESS if ext_result.serial_number else ERROR_CLR)
        conf = ocr_result["confidence"]
        self._conf_bar["value"] = conf
        self._conf_lbl.config(text=f"{conf:.1f}%",
            fg=SUCCESS if conf >= 70 else (WARNING if conf >= 40 else ERROR_CLR))
        self._elapsed_lbl.config(
            text=f"{ocr_result['elapsed']:.3f}s  (pass {ocr_result.get('pass', 1)})")
        self._warn_lbl.config(
            text="\n".join(ext_result.warnings) if ext_result.warnings else "")
        self._raw_text.config(state="normal")
        self._raw_text.delete("1.0", "end")
        self._raw_text.insert("end", ocr_result["text"])
        self._raw_text.config(state="disabled")
        self._results = [{
            "File":          Path(path).name,
            "Model Number":  ext_result.model_number  or "NOT FOUND",
            "Serial Number": ext_result.serial_number or "NOT FOUND",
            "Confidence":    round(conf, 1),
            "Elapsed (s)":   round(ocr_result["elapsed"], 3),
        }]
        self._btn_export.config(state="normal")
        self._refresh_preview()
        self._set_status(f"Done: {Path(path).name}", SUCCESS, "✓")

    def _copy_model(self):
        val = self._model_label.cget("text")
        if val and val != "—":
            self.clipboard_clear()
            self.clipboard_append(val)
            self._set_status(f"Copied model: {val}", ACCENT, "◈")

    def _copy_serial(self):
        val = self._serial_label.cget("text")
        if val and val != "—":
            self.clipboard_clear()
            self.clipboard_append(val)
            self._set_status(f"Copied serial: {val}", ACCENT, "◈")

    def _export_excel(self):
        if not self._results:
            messagebox.showinfo("Export", "No results to export yet.")
            return
        save_path = filedialog.asksaveasfilename(defaultextension=".xlsx",
            filetypes=[("Excel", "*.xlsx")], initialfile="daikin_ocr_results.xlsx")
        if not save_path:
            return
        df = pd.DataFrame(self._results)
        df.to_excel(save_path, index=False)
        self._set_status(f"Exported → {Path(save_path).name}", SUCCESS, "✓")
        messagebox.showinfo("Export Successful", f"Results saved to:\n{save_path}")
