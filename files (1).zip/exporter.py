"""
exporter.py — Export OCR batch results to Excel (.xlsx)
"""

import pandas as pd
from datetime import datetime


def to_excel(results: list[dict], path: str) -> None:
    """
    Write batch OCR results to an Excel file with formatting.

    Parameters
    ----------
    results : list of dicts with keys:
        File, Model Number, Serial Number, Confidence (%), Time (ms), Preset Used
    path : output .xlsx file path
    """
    if not results:
        raise ValueError("No results to export.")

    df = pd.DataFrame(results)

    # Add timestamp column
    df.insert(0, "Timestamp", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="OCR Results", index=False)

        ws = writer.sheets["OCR Results"]

        # ── Column widths ──────────────────────────────────────────────────────
        col_widths = {
            "A": 20,   # Timestamp
            "B": 22,   # File
            "C": 18,   # Model Number
            "D": 16,   # Serial Number
            "E": 16,   # Confidence
            "F": 12,   # Time (ms)
            "G": 12,   # Preset Used
        }
        for col, width in col_widths.items():
            ws.column_dimensions[col].width = width

        # ── Header styling ────────────────────────────────────────────────────
        try:
            from openpyxl.styles import PatternFill, Font, Alignment, Border, Side

            header_fill  = PatternFill("solid", fgColor="0077B6")
            header_font  = Font(bold=True, color="FFFFFF", size=11)
            center_align = Alignment(horizontal="center", vertical="center")
            thin_border  = Border(
                left=Side(style="thin", color="1E3A4F"),
                right=Side(style="thin", color="1E3A4F"),
                bottom=Side(style="thin", color="1E3A4F"),
            )
            found_fill   = PatternFill("solid", fgColor="D4EDDA")  # green tint
            missing_fill = PatternFill("solid", fgColor="F8D7DA")  # red tint

            for cell in ws[1]:
                cell.fill      = header_fill
                cell.font      = header_font
                cell.alignment = center_align
                cell.border    = thin_border

            for row in ws.iter_rows(min_row=2):
                for cell in row:
                    cell.alignment = center_align
                    cell.border    = thin_border
                    # Highlight missing values
                    if cell.value == "NOT FOUND":
                        cell.fill = missing_fill
                        cell.font = Font(color="721C24", bold=True)
                    elif cell.column == 3 or cell.column == 4:  # Model / Serial cols
                        if cell.value and cell.value != "NOT FOUND":
                            cell.fill = found_fill
                            cell.font = Font(color="155724", bold=True, name="Consolas")

        except ImportError:
            pass  # openpyxl styling optional — data still exports correctly

    return path
