"""
extractor.py
Daikin-specific extraction logic for Model Number and Serial Number.
"""

import re
from dataclasses import dataclass, field

_CORRECTION_MAP = {"O": "0", "I": "1", "B": "8", "S": "5", "Z": "2", "G": "6"}
_STRIP_CHARS = r'[^A-Z0-9]'

_MODEL_RE  = re.compile(r'\b([A-Z]{2,5}[0-9]{2}[A-Z0-9]{3,8})\b')
_SERIAL_RE = re.compile(r'\b(\d{6,9})\b')

_MODEL_KEYWORDS  = {"model", "m/n", "mod", "type", "modelno", "modeln"}
_SERIAL_KEYWORDS = {"ser", "serial", "s/no", "sno", "serialno", "s.no", "ser.no"}


@dataclass
class ExtractionResult:
    model_number:  str = ""
    serial_number: str = ""
    model_confidence:  float = 0.0
    serial_confidence: float = 0.0
    raw_text: str = ""
    warnings: list = field(default_factory=list)


def _correct_ocr(text, numeric_only=False):
    result = []
    for ch in text.upper():
        if numeric_only and ch in _CORRECTION_MAP:
            result.append(_CORRECTION_MAP[ch])
        else:
            result.append(ch)
    return "".join(result)


def _tokenize_lines(text):
    lines = []
    for raw_line in text.splitlines():
        tokens = raw_line.upper().split()
        if tokens:
            lines.append(tokens)
    return lines


def _is_keyword(token, keyword_set):
    clean = re.sub(r'[^A-Z0-9/.]', '', token.upper())
    return clean in keyword_set


def _extract_near_keyword(lines, keyword_set, pattern, window=3):
    best_value = ""
    best_score = 0.0
    for line in lines:
        for idx, token in enumerate(line):
            if _is_keyword(token, keyword_set):
                candidates = line[idx + 1: idx + 1 + window]
                li = lines.index(line)
                if idx == len(line) - 1 and li + 1 < len(lines):
                    candidates += lines[li + 1][:window]
                for pos, cand in enumerate(candidates):
                    cand_clean = re.sub(_STRIP_CHARS, '', cand)
                    m = pattern.search(cand_clean)
                    if m:
                        score = 1.0 / (pos + 1)
                        if score > best_score:
                            best_score = score
                            best_value = m.group(1)
    return best_value, best_score


def _looks_like_noise(numeric_str):
    n = int(numeric_str)
    if 2000 <= n <= 2035:
        return True
    if numeric_str == numeric_str[0] * len(numeric_str):
        return True
    return False


def extract(raw_text, ocr_confidence=0.0):
    result = ExtractionResult(raw_text=raw_text)
    lines  = _tokenize_lines(raw_text)

    model_val, model_score = _extract_near_keyword(lines, _MODEL_KEYWORDS, _MODEL_RE, window=4)
    serial_val, serial_score = _extract_near_keyword(lines, _SERIAL_KEYWORDS, _SERIAL_RE, window=4)

    if not model_val:
        corrected = _correct_ocr(raw_text, numeric_only=False)
        all_models = _MODEL_RE.findall(corrected)
        if all_models:
            model_val   = max(all_models, key=len)
            model_score = 0.3

    if not serial_val:
        corrected = _correct_ocr(raw_text, numeric_only=True)
        all_serials = _SERIAL_RE.findall(corrected)
        if all_serials:
            filtered = [s for s in all_serials if not _looks_like_noise(s)]
            if filtered:
                serial_val   = filtered[0]
                serial_score = 0.3

    if model_val:
        model_val = re.sub(_STRIP_CHARS, '', model_val.upper())

    result.model_number       = model_val
    result.serial_number      = serial_val
    result.model_confidence   = round(min(model_score * 100, 100), 1)
    result.serial_confidence  = round(min(serial_score * 100, 100), 1)

    if not model_val:
        result.warnings.append("Model number not detected. Try a clearer image.")
    if not serial_val:
        result.warnings.append("Serial number not detected. Try a clearer image.")

    return result


def extract_batch(texts, confidences=None):
    if confidences is None:
        confidences = [0.0] * len(texts)
    return [extract(t, c) for t, c in zip(texts, confidences)]
