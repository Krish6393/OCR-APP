# Daikin AC Label OCR Tool

A fast desktop application for Daikin service centers to extract **Model Number** and **Serial Number** from AC unit label photos using Tesseract OCR.

---

## Folder Structure

```
daikin_ocr/
├── main.py           ← Entry point (run this)
├── ocr_engine.py     ← Image preprocessing + Tesseract OCR
├── extractor.py      ← Daikin-specific regex & extraction logic
├── ui.py             ← Tkinter desktop UI
├── requirements.txt  ← Python dependencies
└── daikin_ocr.spec   ← PyInstaller packaging config
```

---

## Prerequisites

### 1. Install Tesseract OCR (system binary)

| Platform | Command |
|----------|---------|
| **Windows** | Download from [UB-Mannheim/tesseract](https://github.com/UB-Mannheim/tesseract/wiki) and install to `C:\Program Files\Tesseract-OCR\` |
| **macOS**   | `brew install tesseract` |
| **Ubuntu/Debian** | `sudo apt install tesseract-ocr` |

Verify: `tesseract --version`

### 2. Install Python dependencies

```bash
pip install -r requirements.txt
```

> **Note:** On some Linux distros you may also need: `sudo apt install python3-tk`

---

## Running the App

```bash
python main.py
```

**Keyboard shortcuts:**
- `Ctrl+O` — Upload image
- `Enter`  — Run OCR

---

## How It Works

### Preprocessing Pipeline (`ocr_engine.py`)
1. **Auto-rotate** — Corrects upside-down or tilted label photos
2. **Grayscale conversion** — Removes colour noise
3. **Contrast enhancement** — Alpha=2.0, Beta=40 (sharpens text)
4. **Gaussian blur** — Removes camera grain
5. **Adaptive thresholding** — Binarises image for Tesseract

### Extraction Logic (`extractor.py`)
| Field | Strategy |
|-------|----------|
| **Model Number** | Context search near "MODEL" / "M/N" keywords, then regex `[A-Z]{2,5}[0-9]{2}[A-Z0-9]{3,8}` |
| **Serial Number** | Context search near "SER" / "S/NO" keywords, then regex `\b\d{6,9}\b` |

**OCR error corrections applied:**
- `O → 0`, `I → 1`, `B → 8`, `S → 5`, `Z → 2`, `G → 6`

### Fallback Strategy
- Pass 1: Block-text PSM config on standard preprocessing
- Pass 2 (if confidence < 50%): Sparse PSM with inverted thresholding
- The higher-confidence result is used automatically

---

## Features

| Feature | Details |
|---------|---------|
| Single image upload | JPG, PNG, BMP, TIFF |
| Batch processing | Queue multiple images, export all to Excel |
| Image preview | Shows original or preprocessed view |
| Detection highlights | Green boxes around matched keywords |
| Confidence score | 0–100% OCR confidence meter |
| Copy to clipboard | One-click copy of Model / Serial |
| Export to Excel | `.xlsx` with all batch results |
| Processing time | Target: < 2 seconds per image |

---

## Packaging as .exe (Windows)

```bash
pip install pyinstaller
pyinstaller daikin_ocr.spec
```

Before packaging, edit `daikin_ocr.spec` to point `binaries` at your Tesseract installation path.

Output will be in `dist/DaikinOCR/DaikinOCR.exe`.

---

## Tested Label Format

Validated against Daikin outdoor condensing unit labels with layout:

```
MODEL  RKM50XV16MKA          SER. NO.  0007836
```

Other supported model patterns:
- `FTKM50U`
- `FTKM50YV16KMB`
- `RKM50XV16MKA`
- `ATM50MV1W9`

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| `TesseractNotFoundError` | Install Tesseract binary; on Windows set the path in `main.py` |
| Model not detected | Use better lighting; try the "Show preprocessed" toggle to check image quality |
| Low confidence score | Ensure label is flat, well-lit, in focus; avoid glare |
| App opens but crashes | Ensure `python-tk` is installed on Linux |

---

## Tech Stack

- **Python 3.10+**
- **OpenCV** — Image preprocessing
- **pytesseract** — Tesseract OCR wrapper
- **Pillow** — Tkinter image integration
- **pandas + openpyxl** — Excel export
- **Tkinter** — Cross-platform GUI
