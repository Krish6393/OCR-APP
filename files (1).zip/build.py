"""
build.py — PyInstaller packaging script for Daikin OCR Tool

Run this script from the project root:
    python build.py

Output: dist/DaikinOCR.exe  (Windows)
        dist/DaikinOCR      (macOS / Linux)

Requirements:
    pip install pyinstaller
    (All other deps from requirements.txt must also be installed)
"""

import subprocess
import sys
import os

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
ENTRY_POINT = os.path.join(PROJECT_DIR, "main.py")
APP_NAME    = "DaikinOCR"
ICON_PATH   = os.path.join(PROJECT_DIR, "assets", "icon.ico")   # optional


def build():
    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--onefile",
        "--windowed",              # no console window (GUI mode)
        f"--name={APP_NAME}",
        "--hidden-import=pytesseract",
        "--hidden-import=cv2",
        "--hidden-import=PIL._tkinter_finder",
        "--hidden-import=openpyxl",
        "--hidden-import=pandas",
        "--collect-data=pytesseract",
        "--add-data=ocr_engine.py:.",
        "--add-data=extractor.py:.",
        "--add-data=exporter.py:.",
        "--add-data=ui.py:.",
    ]

    # Add icon if it exists
    if os.path.isfile(ICON_PATH):
        cmd.append(f"--icon={ICON_PATH}")

    cmd.append(ENTRY_POINT)

    print("Building executable with PyInstaller…")
    print(" ".join(cmd))
    result = subprocess.run(cmd, cwd=PROJECT_DIR)
    if result.returncode == 0:
        print(f"\n✅  Build complete! Executable in: dist/{APP_NAME}")
    else:
        print("\n❌  Build failed. Check the output above for errors.")
        sys.exit(result.returncode)


if __name__ == "__main__":
    build()
