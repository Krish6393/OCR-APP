"""
main.py — Entry point for Daikin AC Label OCR Tool

Usage:
    python main.py                  # Launch GUI
    python main.py path/to/img.jpg  # CLI single-image mode (no GUI needed)
"""

import sys
import os


def _check_dependencies() -> list:
    missing = []
    for import_name in ["pytesseract", "cv2", "PIL", "pandas", "openpyxl"]:
        try:
            __import__(import_name)
        except ImportError:
            missing.append(import_name)
    return missing


def _cli_mode(image_path: str):
    """Run OCR on a single image and print results to stdout (no Tkinter needed)."""
    import ocr_engine
    import extractor

    if not os.path.isfile(image_path):
        print(f"[ERROR] File not found: {image_path}")
        sys.exit(1)

    print(f"Processing: {image_path}")
    ocr_res = ocr_engine.process_image(image_path)
    ext_res = extractor.extract_all(ocr_res)

    print("─" * 44)
    print(f"  Model Number  : {ext_res.model  or 'NOT FOUND'}")
    print(f"  Serial Number : {ext_res.serial or 'NOT FOUND'}")
    print(f"  Confidence    : {ext_res.confidence:.1f}%")
    print(f"  Time          : {ext_res.elapsed_ms:.0f} ms")
    print(f"  Preset used   : #{ext_res.preset_used}")
    print("─" * 44)


def main():
    missing = _check_dependencies()
    if missing:
        print("[ERROR] Missing packages:", ", ".join(missing))
        print("Install with:  pip install -r requirements.txt")
        sys.exit(1)

    if len(sys.argv) > 1:
        _cli_mode(sys.argv[1])
    else:
        import ui
        ui.launch()


if __name__ == "__main__":
    main()
