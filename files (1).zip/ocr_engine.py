"""
ocr_engine.py — Daikin Label OCR Engine
Preprocessing pipeline: rotate → grayscale → contrast → blur → threshold → OCR
"""

import cv2
import numpy as np
import pytesseract
import time

# ── Tesseract config ──────────────────────────────────────────────────────────
TESS_CONFIG_FULL = r"--oem 3 --psm 6"
TESS_CONFIG_OSD  = r"--psm 0"

# ── Preprocessing presets (tried in order until confidence threshold met) ─────
PRESETS = [
    {"alpha": 2.0, "beta": 40,  "blur": 3, "block": 31, "c": 10},  # default
    {"alpha": 1.5, "beta": 20,  "blur": 5, "block": 51, "c": 15},  # softer
    {"alpha": 2.5, "beta": 60,  "blur": 1, "block": 21, "c": 5 },  # sharp
    {"alpha": 3.0, "beta": 80,  "blur": 5, "block": 41, "c": 20},  # high contrast
]
CONF_THRESHOLD = 70.0  # stop retrying if avg confidence exceeds this


# ─────────────────────────────────────────────────────────────────────────────
def load_image(path: str) -> np.ndarray:
    img = cv2.imread(path)
    if img is None:
        raise FileNotFoundError(f"Cannot read image: {path}")
    return img


def auto_rotate(img: np.ndarray) -> np.ndarray:
    """Use Tesseract OSD to detect and correct rotation (90°/180°/270°)."""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    try:
        osd = pytesseract.image_to_osd(
            gray,
            output_type=pytesseract.Output.DICT,
            config=TESS_CONFIG_OSD
        )
        angle = osd.get("rotate", 0)
        if angle != 0:
            h, w = img.shape[:2]
            center = (w // 2, h // 2)
            M = cv2.getRotationMatrix2D(center, -angle, 1.0)
            img = cv2.warpAffine(
                img, M, (w, h),
                flags=cv2.INTER_CUBIC,
                borderMode=cv2.BORDER_REPLICATE
            )
    except Exception:
        pass  # OSD can fail on small images — continue without rotation
    return img


def _deskew(img: np.ndarray) -> np.ndarray:
    """Correct slight skew (±15°) using minAreaRect on dark pixels."""
    try:
        coords = np.column_stack(np.where(img < 128))
        if len(coords) < 100:
            return img
        angle = cv2.minAreaRect(coords)[-1]
        if angle < -45:
            angle = -(90 + angle)
        else:
            angle = -angle
        if abs(angle) > 15:
            return img  # implausibly large — skip
        h, w = img.shape
        M = cv2.getRotationMatrix2D((w // 2, h // 2), angle, 1.0)
        return cv2.warpAffine(
            img, M, (w, h),
            flags=cv2.INTER_CUBIC,
            borderMode=cv2.BORDER_REPLICATE
        )
    except Exception:
        return img


def preprocess(img: np.ndarray, preset: dict) -> np.ndarray:
    """Apply full preprocessing pipeline for a given preset."""
    gray    = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    enhanced = cv2.convertScaleAbs(gray, alpha=preset["alpha"], beta=preset["beta"])
    k = preset["blur"]
    blurred = cv2.GaussianBlur(enhanced, (k, k), 0) if k > 1 else enhanced
    thresh  = cv2.adaptiveThreshold(
        blurred, 255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        preset["block"],
        preset["c"]
    )
    return _deskew(thresh)


def detect_label_region(img: np.ndarray):
    """
    Try to isolate the white label sticker within the image.
    Returns (cropped_img, bbox_tuple) or (original_img, None).
    """
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray, 220, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    h_img, w_img = img.shape[:2]
    min_area = (w_img * h_img) * 0.05

    best, best_area = None, 0
    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        area  = w * h
        ratio = w / h if h > 0 else 0
        if area > min_area and 0.5 < ratio < 6.0 and area > best_area:
            best_area = area
            best = (x, y, w, h)

    if best:
        x, y, w, h = best
        pad = 10
        x1, y1 = max(0, x - pad), max(0, y - pad)
        x2, y2 = min(w_img, x + w + pad), min(h_img, y + h + pad)
        return img[y1:y2, x1:x2], (x1, y1, x2, y2)

    return img, None


def run_ocr(processed: np.ndarray):
    """Run Tesseract; return (full_text_uppercase, avg_confidence)."""
    data = pytesseract.image_to_data(
        processed,
        config=TESS_CONFIG_FULL,
        output_type=pytesseract.Output.DICT
    )
    confs = [c for c, w in zip(data["conf"], data["text"])
             if w.strip() and c != -1]
    text  = pytesseract.image_to_string(processed, config=TESS_CONFIG_FULL).upper()
    avg_conf = float(np.mean(confs)) if confs else 0.0
    return text, avg_conf


# ── Public entry point ────────────────────────────────────────────────────────
def process_image(path: str, try_label_crop: bool = True) -> dict:
    """
    Full pipeline for one image.

    Returns dict with keys:
        raw_text        str
        confidence      float  (0–100)
        preset_used     int
        elapsed_ms      float
        preprocessed_img  np.ndarray
        original_img      np.ndarray
        bbox            tuple | None
    """
    t0 = time.perf_counter()

    img      = load_image(path)
    img      = auto_rotate(img)
    original = img.copy()

    if try_label_crop:
        img, bbox = detect_label_region(img)
    else:
        bbox = None

    best_result = None
    best_conf   = -1.0

    for idx, preset in enumerate(PRESETS):
        processed = preprocess(img, preset)
        text, conf = run_ocr(processed)

        if conf > best_conf:
            best_conf = conf
            best_result = {
                "raw_text":        text,
                "confidence":      round(conf, 1),
                "preset_used":     idx,
                "preprocessed_img": processed,
                "original_img":    original,
                "bbox":            bbox,
            }

        if conf >= CONF_THRESHOLD:
            break  # good enough — skip remaining presets

    elapsed = (time.perf_counter() - t0) * 1000
    best_result["elapsed_ms"] = round(elapsed, 1)
    return best_result
